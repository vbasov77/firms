<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css"
          integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/window.css')); ?>">
    <section>
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-10">
                        <?php if($firm->path != null): ?>

                            <img src="<?php echo e(asset("storage/images/logo/$firm->path")); ?>"
                                 style="width: 70px; height: auto" class="card-img-top"
                                 alt="...">
                        <?php else: ?>
                            <img src="<?php echo e(asset("images/no_image/no_image.jpg")); ?>" class="card-img-top"
                                 style="width: 30px; height: auto" alt="...">
                        <?php endif; ?>

                    <div class="field">
                        <b style="font-size: 23px"><?php echo $firm['name']; ?></b>
                        <?php if(auth()->check()): ?>
                            <div class="textRight link" onclick="openNameForm()">Прокомментировать <i
                                        class="fas fa-comment"></i></div><?php endif; ?>
                    </div>
                    <p style="color:green;" id="infoName">Ваша заметка добавлена <i class="fas fa-thumbs-up"></i></p>
                    <div id="name"></div>
                    
                    <div class="form-popup" id="nameForm">
                        <form id="addName" class="form-container">
                            <?php echo csrf_field(); ?>
                            <h4>Ваша заметка</h4>

                            <input type="text" placeholder="Ваш коммнет" id="name_text" name="name_comment"
                                   required>
                            <button type="submit" class="btn submitName" id="submitName">Отправить</button>
                            <button type="button" class="btn cancel" onclick="closeNameForm()">Закрыть</button>
                        </form>
                    </div>
                    
                    <br>
                    <div class="justify-content-start text-left">
                        <div class="field">
                            <b>Инн:</b>
                            <?php if(auth()->check()): ?>
                                <div class="textRight link" onclick="openForm()">Прокомментировать <i
                                            class="fas fa-comment"></i></div><?php endif; ?>
                            
                            <div class="form-popup" id="innForm">
                                <form id="add_inn" class="form-container">
                                    <?php echo csrf_field(); ?>
                                    <h4>Ваша заметка</h4>

                                    <input type="text" placeholder="Ваш коммнет" id="inn_text" name="inn_comment"
                                           required>
                                    <button type="submit" class="btn submitInn" id="submitInn">Отправить</button>
                                    <button type="button" class="btn cancel" onclick="closeForm()">Закрыть</button>
                                </form>
                            </div>
                            
                            <br>
                            <?php echo $firm->inn; ?>

                            <p style="color:green;" id="infoInn">Ваша заметка добавлена <i class="fas fa-thumbs-up"></i></p>
                            <div id="inn"></div>
                        </div>
                        <div class="field">
                            <b>Подробнее:</b>
                            <?php if(auth()->check()): ?>
                                <div class="textRight link" onclick="openAboutForm()">Прокомментировать <i
                                            class="fas fa-comment"></i></div><?php endif; ?>
                            <br> <?php echo $firm->about; ?>

                            <p style="color:green;" id="infoAbout">Ваша заметка добавлена<i class="fas fa-thumbs-up"></i></p>
                            <div id="about"></div>
                            
                            <div class="form-popup" id="aboutForm">
                                <form id="addAbout" class="form-container">
                                    <?php echo csrf_field(); ?>
                                    <h4>Ваша заметка</h4>

                                    <input type="text" placeholder="Ваш коммнет" id="about_text" name="about_comment"
                                           required>
                                    <button type="submit" class="btn submitAbout" id="submitAbout">Отправить</button>
                                    <button type="button" class="btn cancel" onclick="closeAboutForm()">Закрыть</button>
                                </form>
                            </div>
                            
                            <br>
                        </div>
                        <div class="field">
                            <b>Ген. дир:</b>
                            <?php if(auth()->check()): ?>
                            <div class="textRight link" onclick="openDirForm()">Прокомментировать
                                <i class="fas fa-comment"></i></div><?php endif; ?>
                            <br> <?php echo $firm->general_director; ?>

                            <p style="color:green;" id="infoDir">Ваша заметка добавлена <i class="fas fa-thumbs-up"></i></p>
                            <div id="dir"></div>
                            
                            <div class="form-popup" id="dirForm">
                                <form id="addDir" class="form-container">
                                    <?php echo csrf_field(); ?>
                                    <h4>Ваша заметка</h4>

                                    <input type="text" placeholder="Ваш коммнет" id="dir_text" name="dir_comment"
                                           required>
                                    <button type="submit" class="btn submitDir" id="submitDir">Отправить</button>
                                    <button type="button" class="btn cancel" onclick="closeDirForm()">Закрыть</button>
                                </form>
                            </div>
                            
                        </div>
                        <div class="field">
                            <b>Адрес:</b>
                            <?php if(auth()->check()): ?>
                            <div class="textRight link" onclick="openAddrForm()">Прокомментировать <i
                                        class="fas fa-comment"></i></div><?php endif; ?>
                            <br>
                            <?php echo $firm->address; ?>

                            <p style="color:green;" id="infoAddr">Ваша заметка добавлена<i class="fas fa-thumbs-up"></i></p>
                            <div id="addr"></div>
                            
                            <div class="form-popup" id="addrForm">
                                <form id="addAddr" class="form-container">
                                    <?php echo csrf_field(); ?>
                                    <h4>Ваша заметка</h4>
                                    <input type="text" placeholder="Ваш коммнет" id="addr_text" name="addr_comment"
                                           required>
                                    <button type="submit" class="btn submitAddr" id="submitAddr">Отправить</button>
                                    <button type="button" class="btn cancel" onclick="closeAddrForm()">Закрыть</button>
                                </form>
                            </div>
                            
                        </div>
                        <div class="field">
                            <b>Телефон:</b>
                            <?php if(auth()->check()): ?>
                            <div class="textRight link" onclick="openPhForm()">Прокомментировать <i
                                        class="fas fa-comment"></i></div><?php endif; ?>
                            <br> <?php echo $firm->phone; ?>

                            <p style="color:green;" id="infoPh">Ваша заметка добавлена <i class="fas fa-thumbs-up"></i></p>
                            <div id="ph"></div>
                            <div class="form-popup" id="phForm">
                                
                                <form id="addPh" class="form-container">
                                    <?php echo csrf_field(); ?>
                                    <h4>Ваша заметка</h4>
                                    <input type="text" placeholder="Ваш коммнет" id="ph_text" name="ph_comment"
                                           required>
                                    <button type="submit" class="btn submitPh" id="submitPh">Отправить</button>
                                    <button type="button" class="btn cancel" onclick="closePhForm()">Закрыть</button>
                                </form>
                                

                            </div>
                            <div class="justify-content-center text-center">
                                <?php if(auth()->guard()->guest()): ?>
                                <?php else: ?>
                                    <button class="btn btn-success" style="color: white;"
                                            onclick="window.location.href = '<?php echo e(route('edit.firm', ['id'=>$firm->id])); ?>';">
                                        Редактировать фирму
                                    </button>
                                    <a onClick="return confirm('Подтвердите удаление!')"
                                       href='<?php echo e(route('delete.firm', ['id'=>$firm->id])); ?>' type='button'
                                       class='btn btn-danger' style="margin: 5px">Удалить</a>
                                <?php endif; ?>
                            </div>
                            <br>
                        </div>

                    </div>

                    
                    <div class="card mt-4">
                        <h5 class="card-header">Комментарии <span
                                    class="comment-count float-right badge badge-info"><?php echo e(count($firm->comments)); ?></span>
                        </h5>
                        <div class="card-body">
                            
                            <div class="add-comment mb-3">
                                <?php echo csrf_field(); ?>
                                <textarea class="form-control comment" placeholder="Введите комментарий"></textarea>
                                <button data-firm="<?php echo e($firm->id); ?>"
                                        class="btn btn-success btn-sm mt-2 save-comment">
                                    Добавить
                                </button>
                            </div>
                            <hr/>

                            <div class="comments">
                                <?php if(count($firm->comments)>0): ?>
                                    <?php $__currentLoopData = $firm->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <blockquote class="blockquote">
                                            <small class="mb-0"><?php echo e($comment->comment_text); ?></small>
                                            <br><small style="font-size: 10px"
                                                       class="mb-0 justify-content-start"><?php echo $firm->created_at; ?></small>
                                        </blockquote>
                                        <hr/>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p class="no-comments">Нет комментариев</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <?php if(auth()->guard()->guest()): ?>
    <?php else: ?>
        <script>
            var firm_id = <?php echo json_encode($firm->id, 15, 512) ?>;
            var user_id = <?php echo json_encode($userId, 15, 512) ?>;
        </script>
        <script src="<?php echo e(asset('js/firm/name.js')); ?>"></script>
        <script src="<?php echo e(asset('js/firm/inn.js')); ?>"></script>
        <script src="<?php echo e(asset('js/firm/about.js')); ?>"></script>
        <script src="<?php echo e(asset('js/firm/dir.js')); ?>"></script>
        <script src="<?php echo e(asset('js/firm/address.js')); ?>"></script>
        <script src="<?php echo e(asset('js/firm/ph.js')); ?>"></script>
    <?php endif; ?>
    <script>
        // Save Comment
        $(".save-comment").on('click', function () {
            var _comment = $(".comment").val();
            var _firm = $(this).data('firm');
            var vm = $(this);
            // Run Ajax
            $.ajax({
                url: "<?php echo e(url('/save_comment')); ?>",
                type: "post",
                dataType: 'json',
                data: {
                    comment: _comment,
                    firm: _firm,
                    _token: "<?php echo e(csrf_token()); ?>"
                },

                beforeSend: function () {
                    vm.text('Добавляем...').addClass('disabled');

                },
                success: function (res) {
                    var _html = '<blockquote class="blockquote">\
            <small class="mb-0">' + _comment + '</small>\
            <br><small style="font-size: 10px" class="mb-0 text-left">' + res.date + '</small>\
            </blockquote><hr/>';
                    if (res.bool == true) {
                        $(".comments").prepend(_html);
                        $(".comment").val('');
                        $(".comment-count").text($('blockquote').length);
                        $(".no-comments").hide();
                    }
                    vm.text('Добавить').removeClass('disabled');
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\firms\resources\views/firms/view.blade.php ENDPATH**/ ?>