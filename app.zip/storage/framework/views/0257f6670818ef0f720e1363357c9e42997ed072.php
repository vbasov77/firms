<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <section class="section text-center">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <?php $__currentLoopData = $firms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card" style="width: 18rem;margin: 5px">
                        <div class="card-body text-left">
                            <div class="text-right">
                                <?php if($value->path != null): ?>
                                    <img src="<?php echo e(asset("storage/images/logo/$value->path")); ?>"
                                         style="width: 30px; height: auto" class="card-img-top"
                                         alt="...">
                                <?php else: ?>
                                    <img src="<?php echo e(asset("images/no_image/no_image.jpg")); ?>" class="card-img-top"
                                         style="width: 30px; height: auto" alt="...">
                                <?php endif; ?>
                            </div>
                            <div style="margin-top: 10px">
                                <a href="<?php echo e(route('view.firm', ['id'=>$value ['id']])); ?>"> <?php echo $value->name; ?></a>
                            </div>
                            Адрес: <?php echo $value->address; ?><br>
                            Телефон: <?php echo $value->phone; ?><br>
                            Генеральный директор: <?php echo $value->general_director; ?><br>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\firms\resources\views/front.blade.php ENDPATH**/ ?>