<?php $__env->startSection('content'); ?>

    <section>
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <h1>Добавить фирму</h1>
                    <form action="<?php echo e(route('add.firm')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div>
                            <label for="name"><b>Название:</b></label>
                            <input name="name" type="text" value="<?php echo e(old('name')); ?>"
                                   class="form-control"
                                   placeholder="Название...." autocomplete="off" required>
                        </div>
                        <br>
                        <div>
                            <label for="inn"><b>ИНН:</b></label>
                            <input name="inn" type="number" value="<?php echo e(old('inn')); ?>"
                                   class="form-control"
                                   placeholder="ИНН...." autocomplete="off" required>
                        </div>
                        <br>
                        <div>
                            <label for="about"><b>Текст:</b></label>
                            <textarea placeholder="Введите текст..." name="about" cols="85" rows="5"
                                      value="<?php echo e(old('about')); ?>" class="form-control"></textarea>
                        </div>
                        <br>
                        <div>
                            <label for="general_director"><b>Генеральный директор:</b></label>
                            <input name="general_director" type="text" value="<?php echo e(old('general_director')); ?>"
                                   class="form-control"
                                   placeholder="Генеральный директор (ФИО)" autocomplete="off" required>
                        </div>
                        <br>
                        <div>
                            <label for="address"><b>Адрес:</b></label>
                            <input name="address" type="text" value="<?php echo e(old('address')); ?>"
                                   class="form-control"
                                   placeholder="Адрес...." autocomplete="off" required>
                        </div>
                        <br>
                        <div>
                            <label for="phone"><b>Телефон:</b></label>
                            <input name="phone" type="text" value="<?php echo e(old('phone')); ?>"
                                   class="form-control"
                                   placeholder="Телефон...." autocomplete="off" required>
                        </div>
                        <br>
                        <div>
                            <label for="image"><b>Лого:</b></label><br>
                            <input name="image" type="file" value="<?php echo e(old('image')); ?>" class="btn btn-primary submit">
                        </div>
                        <br>
                        <br><center>
                        <button class="btn btn-primary submit" id="submit" type="submit">Добавить</button></center>

                    </form>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\firms\resources\views/firms/add.blade.php ENDPATH**/ ?>