<?php $__env->startSection('content'); ?>
    <section>
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center text-center">
                <div class="col-lg-10">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('edit.firm')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($firm['id']); ?>">
                        <h3>Редактировать</h3>
                        <label for="name"><b>Название</b></label><br>
                        <input type="text" placeholder="Название" class="form-control" name="name"
                               value="<?php echo e($firm['name']); ?>"
                               required><br>
                        <br>
                        <label for="inn"><b>ИНН:</b></label><br>
                        <input type="text" placeholder="ИНН...." class="form-control" name="inn"
                               value="<?php echo e($firm['inn']); ?>"
                               required><br>
                        <br>

                        <div>
                            <label for="about"><b>Текст:</b></label><br>
                            <textarea class="form-control" placeholder="Введите текст" name="about" id="text"
                                      rows="5" cols="85"> <?php echo e($firm['about']); ?></textarea><br>
                        </div>

                        <br>
                        <label for="general_director"><b>Генеральный директор:</b></label><br>
                        <input type="text" placeholder="Генеральный директор (ФИО)" class="form-control"
                               name="general_director"
                               value="<?php echo e($firm['general_director']); ?>"
                               required><br>
                        <br>
                        <div>
                            <label for="address"><b>Адрес:</b></label>
                            <input name="address" type="text" value="<?php echo e($firm['address']); ?>"
                                   class="form-control"
                                   placeholder="Адрес...." autocomplete="off" required>
                        </div>
                        <div>
                            <label for="phone"><b>Телефон:</b></label>
                            <input name="phone" type="text" value="<?php echo e($firm['phone']); ?>"
                                   class="form-control"
                                   placeholder="Телефон...." autocomplete="off" required>
                        </div>
                        <br>
                        <div>
                            <label for="old_image"><b>Лого:</b></label><br>
                            <input name="old_image" type="text" value="<?php echo e($logo); ?>" readonly class="form-control">
                        </div>
                        <br>
                        <div>
                            <label for="mage"><b>Лого:</b></label><br>
                            <input name="image" type="file" value="" class="btn btn-primary submit">
                        </div>
                        <br>
                        <br>
                        <button class="btn btn-outline-danger"
                                onclick="window.location.href = '<?php echo e(route('view.firm', ['id'=>$firm->id])); ?>';">Отмена
                        </button>
                        <input class="btn btn-outline-primary" type="submit" value="Сохранить">
                    </form>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\firms\resources\views/firms/edit.blade.php ENDPATH**/ ?>